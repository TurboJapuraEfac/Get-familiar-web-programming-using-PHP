<?php
ob_start();
session_start();
?>
<!DOCTYPE HTML>  
<html>
<head>


<style>
  .error {color: #FF0000;}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
</style>

</head>
<body>  
<ul>
        <li><a class="active" href="index.html">Home</a></li>
        
        <li><a href="result.php">Results</a></li>

        <li><a href="form2.php">Form 2</a></li>

        <li><a href="form3.php">Form 3</a></li>


</ul>
    
<?php
$nameErr = $emailErr = $genderErr = $websiteErr = $titleErr="";
$name = $email = $gender = $comment = $title=$regnum = $regnumErr="";


if ($_SERVER["REQUEST_METHOD"] == "POST") //this method is more secure than GET method
{


if (empty($_POST["title"])) {
    $titleErr = "Title is required ";
  } else {
     $title = test_input($_POST["title"]) ;
    }
  }


  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
      $nameErr = "Only letters and white space allowed";
      $name="";
    }
  }
  
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $emailErr = "Invalid email format";
      $email="";
    }
  }
    
  if (empty($_POST["registration"])) {
    $regnumErr = "Registration number is required ";
  } else {
    $regnum = test_input($_POST["registration"]);
    if (!preg_match("/^[0-9]*$/",$regnum)) {
     $regnumErr = "Only numbers are allowed";
     $regnum="";
    }
  }


function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>

<h2> Form 1 </h2>
<p><span class="error">* required field</span></p>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  

  Title: <select name="title" id="">
  <option type="radio" name="gender" <?php if (isset($title) && $gender=="Mr") echo "checked";?> value="Mr">Mr
  <option type="radio" name="gender" <?php if (isset($title) && $gender=="Mrs") echo "checked";?> value="Mrs">Mrs
  <option type="radio" name="gender" <?php if (isset($title) && $gender=="Ms") echo "checked";?> value="Ms">Ms  
 <option type="radio" name="gender" <?php if (isset($title) && $gender=="Rev") echo "checked";?> value="Rev">Rev
  </select>
  <br><br>

  Name: <input type="text" name="name" value="<?php echo $name;?>">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>

  E-mail: <input type="text" name="email" value="<?php echo $email;?>">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>

  Registration: <input type="text" name="registration" value="<?php echo $regnum;?>">
  <span class="error"><?php echo $regnumErr;?></span>
  <br><br>

  <input type="submit" name="submit" value="Submit">  



</form>

<?php
if(empty($_POST["title"])||empty($_POST["name"])||empty($_POST["email"])||empty($_POST["registration"]))
{

}
else
{
 echo "Your information has been submitted"; 
  $myfile = fopen("form1.txt", "w") or die("Unable to open file!");
            $text = "Hi ";
            $text .=$_POST['title'];
            $text .=" ";
            $text .=$_POST['name'];
            $text .=" ";
            $text .=" (";
            $text .=$_POST['registration'];
            $text .=") ";
            $text .=" ";
            $text .="you will be contact via ";
            $text .=$_POST['email'];
            fwrite($myfile, $text); // This is a inbuilt function
            fclose($myfile); // This also is a inbuilt function

 echo " <center><h2> Hi $title $name ($regnum) , you will be contacted via $email </h2> </center>";
}

?>

</body>
</html>