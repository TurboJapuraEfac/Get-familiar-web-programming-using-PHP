<?php
ob_start();
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form 2 </title>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
</style>


</head>
<body>
    
    <ul>
        <li><a class="active" href="index.html">Home</a></li>
        
        <li><a href="result.php">Results</a></li>

        <li><a href="form1.php">Form 1</a></li>

        <li><a href="form3.php">Form 3</a></li>
    </ul>
    

    

        <?php

if ( empty($_POST['nic']) || empty($_POST['registration']) ||empty($_POST['telephone']))
         {    echo "Please fill all the boxes " ;  }
else
        {
            if(substr($_POST['nic'], -1)=='v'||substr($_POST['nic'], -1)=='V'){
                $idNum="19";
                $idNum .=substr($_POST['nic'],0,2);
                $idNum .=substr($_POST['nic'],2,3);
                $idNum .="0";
                $idNum .=substr($_POST['nic'],5,3);
                $idNum .=substr($_POST['nic'],8,1);
            }
            else{
                $idNum=$_POST['nic'];
            }
            echo 'Your information has submitted';
            $myfile = fopen("form2.txt", "w") or die("Unable to open file!");
            $text = "Registration no: ";
            $text .=$_POST['registration'];
            $text .= "\n";
            $text .="NIC no: ";
            $text .=$idNum;
            $text .= "\n";
            $text .="Telephone no: ";
            $text .=$_POST['telephone'];
            fwrite($myfile, $text);
            fclose($myfile);
        }
        ?>

       <b>
        <form  role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
            <div >
                <br><br>
                Reg No  : <input type="text" name="registration"  ></br><br>
                NIC No  : <input type="text"  name="nic"  ></br><br>
                Tel No  : <input type="tel"  name="telephone" placeholder="Format: 123-45678" pattern="[0-9]{3}-[0-9]{7}" ></br><br>
                <button  type="submit" name="submit">Submit</button><br>
            </div>
        </form>
     </b>
</body>
</html>