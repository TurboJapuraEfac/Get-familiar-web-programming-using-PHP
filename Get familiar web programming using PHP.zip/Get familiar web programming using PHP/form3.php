<?php
ob_start();
session_start();
?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Calculator</title>
        <style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
</style>

    </head>
    <body>

    <ul>
        <li><a class="active" href="index.html">Home</a></li>
        
        <li><a href="result.php">Results</a></li>

        <li><a href="form1.php">Form 1</a></li>

        <li><a href="form2.php">Form 2</a></li>


    </ul>
    
    <h2><b> Calculator  :</b></h2>

        <form  role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post">
                <input type="number"  name="Num1" placeholder="Enter Num1"  >

                <label for="operator"></label>
                <select name="operator" id="operator" >
                    <option value="">Select</option>
                    <option value="+">+</option>
                    <option value="-">-</option>
                    <option value="*">*</option>
                    <option value="/">/</option>
                </select>

                <input type="number" name="Num2" placeholder="Enter Num2" >
                <button  type="submit" name="submit">Submit</button>
        </form>      
        <?php

        if ( isset($_POST['submit']) && !empty($_POST['Num1']) && !empty($_POST['Num2']) ) 
        {

           
            $myfile = fopen("form3.txt", "w") or die("Unable to open file!");
            $text = $_POST['Num1'];
            $text .= $_POST['operator'];
            $text .= $_POST['Num2'];
            $p = eval('return '.$text.';');
            $text .=" = ";
            fwrite($myfile, $text);
            fwrite($myfile, $p);
            fclose($myfile);
            echo 'Your information has been submitted';
        }
        else{
            echo "Please enter numbers correctly ";
        }
        ?>
    </body>
    </html>