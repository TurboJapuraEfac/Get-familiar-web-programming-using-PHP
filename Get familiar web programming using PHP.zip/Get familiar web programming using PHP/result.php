<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
  .error {color: #FF0000;}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}
</style>
</head>
<body>

<ul>
        <li><a class="active" href="index.html">Home</a></li>
</ul>






    <div  align='center'>
      <b>  <div>
            Form 1 Results: <br>
            <div><br> <?php 
                            $myfile = fopen("form1.txt", "r") or die("Unable to open file!");
                            while (!feof($myfile)) {
                                echo fgets($myfile) . "<br>";
                            }
                            fclose($myfile);
                            ?></div>
                            
        </div></br><br><br><br>
        

        <div>
            Form 2 Results:  <div><br> <?php
                            $myfile = fopen("form2.txt", "r") or die("Unable to open file!");
                            while (!feof($myfile)) {
                                echo fgets($myfile) . "<br>";
                            }
                            fclose($myfile);
                            ?></div>
        </div></br><br><br><br>

        <div>
            Form 3 Results:    <div><br><?php
                            $myfile = fopen("form3.txt", "r") or die("Unable to open file!");
                            while (!feof($myfile)) {
                                echo fgets($myfile) . "<br>";
                            }
                            fclose($myfile);
                            ?></div>
        </div>
        </b>
    </div>
</body>
</html>